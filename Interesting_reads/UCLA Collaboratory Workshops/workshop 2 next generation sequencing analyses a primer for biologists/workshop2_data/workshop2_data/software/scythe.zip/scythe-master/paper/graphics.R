library(qrqc)

## Use testing/test.fastq with qrqc to show variability in bases.
## The qualities in this file are real, not simulated.

s <- readSeqFile("../testing/test.fastq")
